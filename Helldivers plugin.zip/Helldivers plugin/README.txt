1/ installer Runtime .NET 8 : winget install Microsoft.DotNet.Runtime.8
2/ importer le profile (double click io.github.nounns.helldivers.streamDeckPlugin) 
3/ (optionnel, permet d'avoir des icones du jeu) copier pack dans %APPDATA%\Elgato\StreamDeck\Plugins\io.github.nounns.helldivers.sdPlugin\static\imgs\ 
4/ relancer streamdeck (click droit quitter dans la zone de notification)
5/ dans le volet droit, un menu Helldiver 2 apparait avec un icone stratagème à faire glisser dans le profile streamdeck
	Titre : le texte qui s'affichera sur l'icone
	Stratagème : le stratagème souhaité
	Nom : laisser vide
	Code : à personnaliser si nécessaire mais les stratagème embarque déjà les codes
	Recharges :  à personnaliser si nécessaire mais les stratagème embarque déjà les colldown
	Touche stratageme : pour choisir la trouche ingame

INFO générale : 

Appui bref : envoie le code et lance le compte a rebours. 
Appui long : remet le compteur a zero (utile si le stratageme n'a pas ete lance).

Good to know : 

Le jeu ne communique rien : le compte a rebours est une estimation qui demarre a l'appui, alors que la recharge reelle demarre a l'explosion de la balise. Les temps des prereglages changent a chaque patch — le champ Recharge permet de les corriger. Le jeu doit etre configure en mode APPUI (et non maintien) pour la touche stratageme.